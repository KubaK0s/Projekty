const BASE_API = "https://toolsapiforpolsl.azurewebsites.net/api";

export { BASE_API };
