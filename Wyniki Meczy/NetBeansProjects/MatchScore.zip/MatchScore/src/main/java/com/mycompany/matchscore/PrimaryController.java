package com.mycompany.matchscore;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class PrimaryController {
    
    @FXML
    private BorderPane bp;
    @FXML
    private AnchorPane ap;
    @FXML
    private Button addMatch;
    @FXML
    private Button showNick;

    @FXML
    public void menu(MouseEvent event) {
         bp.setCenter(ap);
    }
    @FXML
    public void addNewMatch() throws IOException {
        App.setRoot("test.fxml");
    }

    @FXML
    public void showAllScore(MouseEvent event) {
       
    }

    @FXML
    public void showYourNickName() throws IOException {
        App.setRoot("showNickNamePage.fxml");
    }

    @FXML
    public void page4(MouseEvent event) {
       
    }
    @FXML
    public void exit(MouseEvent event) {
    }
    
//    public void loadPage(String page){
//        Parent root = null;
//        
//        try {
//            root = FXMLLoader.load(getClass().getResource(page+".fxml"));
//        } catch (IOException ex) {
//        }
//        
//     bp.setCenter(root);
//    }

    
}
