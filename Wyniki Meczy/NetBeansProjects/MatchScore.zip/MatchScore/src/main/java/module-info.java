module com.mycompany.matchscore {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.matchscore to javafx.fxml;
    exports com.mycompany.matchscore;
}
